#!/usr/bin/env bash
set -euo pipefail

brew install glib gobject-introspection
brew install gstreamer gst-plugins-base
brew install supervisord
brew install zeromq
