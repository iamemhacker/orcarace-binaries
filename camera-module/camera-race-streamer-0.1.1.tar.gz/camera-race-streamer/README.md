# Camera Race Streamer Operator Guide

## Quick start
1. Unpack the tarball. `tar xzf <package>`
2. Install prerequisites: `./scripts/install_prereqs.sh`
3. Start supervisor: `supervisord -c supervisor/supervisord.conf`

## Notes
- Run `supervisord` from the extracted package root so relative paths resolve correctly.
- Logs are written under `logs/`.
