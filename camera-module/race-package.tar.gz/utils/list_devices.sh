#/bin/bash
# list_if_ipv4.sh
# Output: interface, ipv4

ifconfig | awk '
/^[a-zA-Z0-9]+:/{iface=$1; sub(/:/,"",iface)}
/^[[:space:]]+inet[[:space:]]/{
  ip=$2
  if (ip != "127.0.0.1") {
    print iface ", " ip
  }
}
'
