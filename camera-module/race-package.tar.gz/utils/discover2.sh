#!/usr/bin/env bash
set -euo pipefail

browse_seconds=3
resolve_seconds=8

instances=$(
  timeout "$browse_seconds" dns-sd -B _axis-video._tcp local 2>&1 |
    awk '/ Add /{ sub(/.*_axis-video\._tcp\.[[:space:]]+/, ""); print }' |
    sort -u \
  || true
)

if [[ -z "$instances" ]]; then
  echo "No Axis cameras found."
  exit 0
fi

echo "Instances found:"
printf '%s\n' "$instances" | sed 's/^/  - /'

echo
echo "Resolved:"
printf '%s\n' "$instances" | while IFS= read -r instance; do
  [[ -z "$instance" ]] && continue

  # 1) instance -> dns-sd -L output
  out=$(
    timeout "$resolve_seconds" dns-sd -L "$instance" _axis-video._tcp local 2>&1 \
    || true
  )

  # 2) parse hostname + port from the "can be reached at ..." line
  # Example:
  # AXIS\032... can be reached at axis-e827250e9f55.local.:80 (interface 12)
  line=$(printf '%s\n' "$out" | awk '/can be reached at/ {print; exit}')

  if [[ -z "$line" ]]; then
    echo "instance=$instance  hostname=?  ip=?  (dns-sd -L timeout/failed)"
    continue
  fi

  hostname=$(
    printf '%s\n' "$line" |
      sed -n 's/.* can be reached at \([^:]*\):.*/\1/p' |
      sed 's/\.$//'
  )
  port=$(
    printf '%s\n' "$line" |
      sed -n 's/.*:\([0-9][0-9]*\) .*/\1/p'
  )

  if [[ -z "$hostname" ]]; then
    echo "instance=$instance  hostname=?  ip=?  (parse failed)"
    continue
  fi

  # 3) hostname -> IPv4 via mDNS
  ip=$(
    timeout 3 dns-sd -G v4 "$hostname" 2>&1 |
      awk '/ A / {print $NF; exit}' \
    || true
  )

  echo "instance=$instance  hostname=$hostname  port=${port:-?}  ip=${ip:-?}"
done
