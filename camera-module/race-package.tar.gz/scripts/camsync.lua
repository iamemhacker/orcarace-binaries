local mp = require 'mp'
local utils = require 'mp.utils'

local state = {
  rows = {},         -- {idx=0, cam_ms=..., key=0/1}
  omega_ms = nil,    -- from start_ts.txt
  csv_path = nil,
  start_path = nil,
  osd_on = true,
}

local function trim(s)
  return (s:gsub("^%s+", ""):gsub("%s+$", ""))
end

local function read_all(path)
  local f = io.open(path, "r")
  if not f then return nil end
  local data = f:read("*a")
  f:close()
  return data
end

local function to_int(s)
  if not s then return nil end
  s = trim(s)
  local n = tonumber(s)
  if not n then return nil end
  return math.floor(n)
end

local function parse_csv(csv_text)
  local rows = {}
  local first = true

  for line in csv_text:gmatch("[^\r\n]+") do
    line = trim(line)
    if line ~= "" then
      if first then
        -- header line (ignore)
        first = false
      else
        -- idx,camera_ts_ms,is_keyframe
        local a,b,c = line:match("^(%d+),([^,]+),([^,]+)$")
        if a then
          table.insert(rows, {
            idx = tonumber(a),
            cam_ms = to_int(b),
            key = to_int(c) or 0
          })
        else
          -- fallback: idx,camera_ts_ms
          local x,y = line:match("^(%d+),([^,]+)$")
          if x then
            table.insert(rows, {
              idx = tonumber(x),
              cam_ms = to_int(y),
              key = 0
            })
          end
        end
      end
    end
  end

  return rows
end

local function load_sidecar()
  local video_path = mp.get_property("path")
  if not video_path then return false end
  local dir = utils.split_path(video_path)

  local csv_path = utils.join_path(dir, "camsync.csv")
  local start_path = utils.join_path(dir, "start_ts.txt")

  local csv_text = read_all(csv_path)
  if not csv_text then
    -- also try ./camsync/camsync.csv (in case you opened from parent dir)
    local alt_dir = utils.join_path(dir, "camsync")
    local alt_csv = utils.join_path(alt_dir, "camsync.csv")
    local alt_start = utils.join_path(alt_dir, "start_ts.txt")
    csv_text = read_all(alt_csv)
    if csv_text then
      csv_path = alt_csv
      start_path = alt_start
    end
  end

  if not csv_text then
    mp.osd_message("camsync: FAILED to read camsync.csv", 3)
    mp.msg.error("camsync: FAILED to read camsync.csv")
    return false
  end

  local rows = parse_csv(csv_text)
  if #rows == 0 then
    mp.osd_message("camsync: csv parsed but 0 rows", 3)
    mp.msg.error("camsync: csv parsed but 0 rows")
    return false
  end

  local start_text = read_all(start_path)
  local omega_ms = nil
  if start_text then
    omega_ms = to_int(start_text:match("([0-9]+)"))
  end

  state.rows = rows
  state.omega_ms = omega_ms
  state.csv_path = csv_path
  state.start_path = start_path

  mp.msg.info(("camsync: loaded %d frames"):format(#rows))
  mp.osd_message("camsync loaded. Press 'm' to mark.", 2)
  return true
end

-- Robust mapping: use camera_ts_ms timeline (not FPS estimate)
local function find_nearest_by_cam_ms(target_ms)
  local rows = state.rows
  local n = #rows
  if n == 0 then return nil end

  local lo, hi = 1, n
  while lo < hi do
    local mid = math.floor((lo + hi) / 2)
    if rows[mid].cam_ms < target_ms then
      lo = mid + 1
    else
      hi = mid
    end
  end

  local i = lo
  if i <= 1 then return rows[1] end
  if i >= n then return rows[n] end

  local a = rows[i - 1]
  local b = rows[i]
  if math.abs(a.cam_ms - target_ms) <= math.abs(b.cam_ms - target_ms) then
    return a
  else
    return b
  end
end

local function current_row()
  local t = mp.get_property_number("time-pos", nil)
  if not t then return nil end

  local clip_start_ms = state.rows[1].cam_ms
  if not clip_start_ms then return nil end

  local target_ms = clip_start_ms + math.floor(t * 1000 + 0.5)
  return find_nearest_by_cam_ms(target_ms), target_ms, t
end

local function osd_update()
  if not state.osd_on then return end
  if #state.rows == 0 then return end

  local r, target_ms, t = current_row()
  if not r then return end

  local omega = state.omega_ms
  local delta = (omega and r.cam_ms) and (r.cam_ms - omega) or nil

  local lines = {}
  table.insert(lines, "camsync")
  table.insert(lines, ("time-pos: %.3fs"):format(t))
  table.insert(lines, ("idx: %d   key: %d"):format(r.idx, r.key or 0))
  table.insert(lines, ("camera_ts_ms: %d"):format(r.cam_ms))
  table.insert(lines, ("target_cam_ms: %d"):format(target_ms))
  if omega then
    table.insert(lines, ("omega_start_ms: %d"):format(omega))
  else
    table.insert(lines, "omega_start_ms: n/a (missing start_ts.txt)")
  end
  if delta then
    table.insert(lines, ("delta_ms (camera-omega): %d"):format(delta))
  end

  mp.osd_message(table.concat(lines, "\n"), 0.25)
end

local function write_result()
  if #state.rows == 0 then
    mp.osd_message("camsync: not loaded", 2)
    return
  end

  local r, _, t = current_row()
  if not r then
    mp.osd_message("camsync: could not map current time", 2)
    return
  end

  local omega = state.omega_ms
  local delta = (omega and r.cam_ms) and (r.cam_ms - omega) or nil

  local video_path = mp.get_property("path")
  local dir = utils.split_path(video_path)
  local out_path = utils.join_path(dir, "camsync_result.json")

  local obj = {
    video = video_path,
    csv = state.csv_path,
    start_ts = state.start_path,
    time_pos_sec = t,
    marked_idx = r.idx,
    marked_camera_ts_ms = r.cam_ms,
    omega_start_ms = omega,
    delta_ms = delta,
    is_keyframe = r.key,
  }

  local json = utils.format_json(obj)
  local f = io.open(out_path, "w")
  if not f then
    mp.osd_message("camsync: failed to write result file", 2)
    return
  end
  f:write(json)
  f:write("\n")
  f:close()

  mp.osd_message("camsync: wrote camsync_result.json", 2)
  mp.msg.info("camsync: wrote " .. out_path)
end

mp.register_event("file-loaded", function()
  if load_sidecar() then
    mp.add_periodic_timer(0.1, osd_update)
    mp.add_key_binding("m", "camsync_mark", write_result)
    mp.add_key_binding("o", "camsync_osd", function()
      state.osd_on = not state.osd_on
      mp.osd_message("camsync OSD: " .. (state.osd_on and "ON" or "OFF"), 1)
    end)
  end
end)
